# save_scaler.py
import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
import joblib

# Load your original training data
train_df = pd.read_csv("sample_128_rows.csv")  # Replace with your actual training data

# Initialize and fit the scaler
scaler = MinMaxScaler(feature_range=(0.1, 0.9))  # More conservative than (0,1)
scaler.fit(train_df[['avg_modal_price']].values)

# Save the scaler
joblib.dump(scaler, "models/price_scaler.save")

print("Scaler saved successfully!")
print(f"Data range: Min={scaler.data_min_[0]}, Max={scaler.data_max_[0]}")