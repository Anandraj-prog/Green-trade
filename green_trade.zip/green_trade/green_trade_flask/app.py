from flask import Flask, request, render_template, redirect, url_for, session
import pandas as pd
import numpy as np
import joblib
import os
from datetime import datetime
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import Conv1D, Flatten, Dense, Dropout
from tensorflow.keras.losses import MeanSquaredError
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, r2_score

app = Flask(__name__, template_folder='templates', static_folder='static')
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['ALLOWED_EXTENSIONS'] = {'csv'}
app.secret_key = 'your_secret_key_here'

# Model and evaluation metrics storage
app.config['MODEL_METRICS'] = {
    'mae': None,
    'r2': None,
    'last_trained': None
}

# Improved model architecture
def create_model():
    model = Sequential([
        Conv1D(filters=64, kernel_size=2, activation='relu', input_shape=(3, 1)),
        Dropout(0.2),
        Flatten(),
        Dense(100, activation='relu'),
        Dropout(0.2),
        Dense(50, activation='relu'),
        Dense(1, activation='linear')  # Explicit linear activation for regression
    ])
    model.compile(optimizer='adam', loss='mse')
    return model

def load_or_create_model():
    try:
        model = load_model("models/price_model.h5")
        scaler = joblib.load("models/scaler.save")
        print("Loaded existing model and scaler")
    except:
        model = create_model()
        scaler = MinMaxScaler(feature_range=(0.1, 0.9))  # Avoid 0-1 extremes
        os.makedirs("models", exist_ok=True)
        model.save("models/price_model.h5")
        joblib.dump(scaler, "models/scaler.save")
        print("Created new model and scaler")
    return model, scaler

model, scaler = load_or_create_model()

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

def preprocess_data(filepath):
    """Load CSV and extract unique crop names with data validation"""
    try:
        df = pd.read_csv(filepath)
        df.columns = df.columns.str.lower()
        
        # Validate required columns
        required = ['month', 'commodity', 'avg_modal_price']
        if not all(col in df.columns for col in required):
            raise ValueError("CSV must contain: month, commodity, avg_modal_price")
        
        # Validate price data
        if df['avg_modal_price'].min() <= 0:
            # Replace zeros/negatives with small positive value
            min_price = df[df['avg_modal_price'] > 0]['avg_modal_price'].min()
            df['avg_modal_price'] = df['avg_modal_price'].replace(
                [0, -1], min_price/2)
        
        # Get unique crops and sort
        crops = df['commodity'].unique().tolist()
        crops.sort()
        
        return df, crops
    except Exception as e:
        raise ValueError(f"Error processing CSV: {str(e)}")

def train_model(df):
    """Train model and calculate accuracy metrics"""
    try:
        # ... (existing data preparation code)
        df['month'] = pd.to_datetime(df['month'])
        df = df.sort_values('month')
        
        # Group by commodity and create sequences
        sequences = []
        targets = []
        
        for commodity, group in df.groupby('commodity'):
            prices = group['avg_modal_price'].values.reshape(-1, 1)
            
            # Scale prices for this commodity
            scaler.fit(prices)
            scaled = scaler.transform(prices)
            
            # Create sequences (3 prices predict next price)
            for i in range(len(scaled) - 3):
                sequences.append(scaled[i:i+3])
                targets.append(scaled[i+3])
        
        if not sequences:
            raise ValueError("Not enough data to create training sequences")
        
        X = np.array(sequences)
        y = np.array(targets)
        # Train-test split
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42)
        
        # Train model
        history = model.fit(X_train, y_train, 
                          validation_data=(X_test, y_test),
                          epochs=50,
                          batch_size=32,
                          verbose=1)
        
        # Calculate metrics
        y_pred = model.predict(X_test)
        mae = mean_absolute_error(y_test, y_pred)
        r2 = r2_score(y_test, y_pred)
        
        # Store metrics
        app.config['MODEL_METRICS'] = {
            'mae': mae,
            'r2': r2,
            'last_trained': datetime.now().strftime('%Y-%m-%d %H:%M')
        }
        
        # Save model and scaler
        model.save("models/price_model.h5")
        joblib.dump(scaler, "models/scaler.save")
        
        return True
    except Exception as e:
        raise ValueError(f"Training failed: {str(e)}")

def predict_price(crop_name, df):
    """Predict price with proper data preparation"""
    try:
        crop_data = df[df['commodity'].str.lower() == crop_name.lower()]
        if len(crop_data) < 4:
            raise ValueError(f"Not enough data for {crop_name}")
        
        # Get last 3 prices for this crop
        prices = crop_data['avg_modal_price'].values[-3:].reshape(-1, 1)
        
        # Scale using the fitted scaler
        scaled = scaler.transform(prices)
        sequence = scaled.reshape(1, 3, 1)
        
        # Predict and ensure positive value
        pred = model.predict(sequence)[0][0]
        pred = max(0.05, min(0.95, pred))  # Keep within safe bounds
        predicted_price = scaler.inverse_transform([[pred]])[0][0]
        
        return max(0.1, predicted_price)  # Ensure positive price
    except Exception as e:
        raise ValueError(f"Prediction failed: {str(e)}")



# ... (keep the same route handlers as before)

@app.route('/', methods=['GET', 'POST'])  # Added POST method here
def home():
    """Home page with file upload"""
    if request.method == 'POST':
        if 'file' not in request.files:
            return render_template('home.html', error="No file selected")
            
        file = request.files['file']
        if file.filename == '':
            return render_template('home.html', error="No file selected")
        
        if file and allowed_file(file.filename):
            try:
                filepath = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
                file.save(filepath)
                
                # Process file and get crop names
                df, crops = preprocess_data(filepath)
                train_model(df)
                
                # Store crops in session
                session['crops'] = crops
                session['current_file'] = filepath
                
                return redirect(url_for('predict'))
            except Exception as e:
                return render_template('home.html', error=str(e))
    
    current_date = datetime.now().strftime('%Y%m%d')
    return render_template('home.html', current_date=current_date)

@app.route('/about')
def about():
    """About page explaining the project"""
    return render_template('about.html')

@app.route('/accuracy')
def accuracy():
    """Page showing model accuracy metrics"""
    metrics = app.config['MODEL_METRICS']
    return render_template('accuracy.html', 
                         mae=metrics['mae'],
                         r2=metrics['r2'],
                         last_trained=metrics['last_trained'])

@app.route('/predict', methods=['GET', 'POST'])
def predict():
    """Prediction page with accuracy metrics"""
    if 'crops' not in session:
        return redirect(url_for('home'))
    
    metrics = app.config['MODEL_METRICS']
    
    if request.method == 'POST':
        crop_name = request.form.get('crop_name')
        year = request.form.get('year', '2025')
        
        try:
            df = pd.read_csv(session['current_file'])
            predicted_price = predict_price(crop_name, df)
            
            return render_template('results.html',
                                crop=crop_name,
                                year=year,
                                price=round(predicted_price, 2),
                                metrics=metrics)
        except Exception as e:
            return render_template('predict.html',
                                crops=session['crops'],
                                error=str(e),
                                metrics=metrics)
    
    return render_template('predict.html', 
                         crops=session['crops'],
                         metrics=metrics)


if __name__ == '__main__':
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    app.run(host='0.0.0.0', port=5000, debug=True)