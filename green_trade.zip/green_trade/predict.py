import numpy as np
import pandas as pd
import tensorflow as tf
from keras.losses import MeanSquaredError
from tensorflow.keras.models import load_model
import sys



# Load the trained model
model = load_model("models/price_prediction_cnn.h5", custom_objects={"mse": MeanSquaredError()})

# Load the test dataset (or new data)
test_data = pd.read_csv("data/cleaned_commodity_price_data.csv")

# Select relevant features (modify as per your training features)
features = ["year", "month_num", "change"]  
X_test = test_data[features].values

# Normalize the data (if required, use same method as in training)
X_test = X_test / np.max(X_test, axis=0)  # Example normalization

# Predict prices
predicted_prices = model.predict(X_test)

# Add predictions to the dataset
test_data["Predicted_Price"] = predicted_prices

# Save the results
test_data.to_csv("data/predicted_prices.csv", index=False)

print("✅ Prediction complete! Results saved in 'data/predicted_prices.csv'")
