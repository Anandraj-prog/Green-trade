import pandas as pd
import os

# Define the folder containing data files
data_folder = "data/"

# List all files in the data folder
file_paths = [os.path.join(data_folder, file) for file in [
    "turmeric_price_data.csv",
    "blackpepper_price_data.csv",
    "cauliflower_price_data.csv",
    "tomato_price_data.csv",
    "potato_price_data.csv",
    "onion_price_data.csv",
    "banana_price_data.csv",
    "mango_price_data.csv",
    "apple_price_data.csv"
]]

# Merge all files
merged_df = pd.concat([pd.read_csv(path) for path in file_paths], ignore_index=True)

# Convert 'month' to datetime format
merged_df["month"] = pd.to_datetime(merged_df["month"])

# Fill missing 'change' values
merged_df["change"].fillna(0, inplace=True)

# Extract additional features
merged_df["year"] = merged_df["month"].dt.year
merged_df["month_num"] = merged_df["month"].dt.month
merged_df["season"] = merged_df["month_num"].apply(lambda x: 
    "Winter" if x in [12, 1, 2] else 
    "Summer" if x in [3, 4, 5] else 
    "Monsoon" if x in [6, 7, 8] else 
    "Post-Monsoon")

# Save merged file
merged_df.to_csv("data/cleaned_commodity_price_data.csv", index=False)

print("✅ Merging completed! Data saved in 'data/cleaned_commodity_price_data.csv'")
