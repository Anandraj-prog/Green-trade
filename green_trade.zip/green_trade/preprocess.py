import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

def load_and_preprocess(file_path):
    # Load dataset
    df = pd.read_csv(file_path)

    # Convert 'month' column to datetime
    df["month"] = pd.to_datetime(df["month"])
    df = df.sort_values(by=["commodity_name", "month"])

    # Define window size
    window_size = 3
    X, y = [], []
    commodities = df["commodity_name"].unique()

    for commodity in commodities:
        commodity_data = df[df["commodity_name"] == commodity]
        prices = commodity_data["avg_modal_price"].values

        for i in range(len(prices) - window_size):
            X.append(prices[i:i + window_size])
            y.append(prices[i + window_size])  # Next month's price

    # Convert to numpy arrays
    X, y = np.array(X), np.array(y)

    # Split into training (80%) and testing (20%) sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, shuffle=False)

    return X_train, X_test, y_train, y_test

# Run preprocessing and save data
if __name__ == "__main__":
    X_train, X_test, y_train, y_test = load_and_preprocess("data/cleaned_commodity_price_data.csv")
    np.save("data/X_train.npy", X_train)
    np.save("data/X_test.npy", X_test)
    np.save("data/y_train.npy", y_train)
    np.save("data/y_test.npy", y_test)
    print("✅ Data preprocessing completed and saved!")
