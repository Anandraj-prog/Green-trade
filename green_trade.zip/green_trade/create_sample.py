def preprocess_csv(file_path):
    df = pd.read_csv(file_path)

    # For now, use dummy modal_price (you can replace this with actual logic)
    df["modal_price"] = np.random.randint(1000, 5000, size=len(df))

    df["date"] = pd.to_datetime(df["date"], errors='coerce')
    df["year"] = df["date"].dt.year
    df["month_num"] = df["date"].dt.month

    # Compute % change from previous day (simulated)
    df["change"] = df["modal_price"].pct_change().fillna(0)

    features = ["modal_price", "year", "month_num", "change"]
    scaler = MinMaxScaler()
    scaled_data = scaler.fit_transform(df[features])

    X = np.reshape(scaled_data, (scaled_data.shape[0], scaled_data.shape[1], 1))

    return X, df
